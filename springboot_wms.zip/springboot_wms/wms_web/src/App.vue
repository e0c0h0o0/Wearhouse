<script setup>

</script>

<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style scoped>
#app {
  height: 100%;
}
</style>
