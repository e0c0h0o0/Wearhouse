package com.wms.service;

import com.wms.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author thea
 * @since 2023-11-12
 */
public interface MenuService extends IService<Menu> {

}
